Open anaconda prompt, go to directory repo


pip install -r requirements.txt

usage commmand:
python molecular_triage.py --input full-path/example_molecules.csv --output full-path/triage_results.csv --plot