"""
molecular_triage.py

Quick drug-likeness and rigidity triage for a virtual library.

Given a table of molecules (CSV or Excel with a "SMILES" column), computes:
  - Lipinski Rule-of-Five violations (MW, LogP, HBD, HBA)
  - QED (quantitative estimate of drug-likeness)
  - Synthetic accessibility score (Ertl & Schuffenhauer SA_Score, via RDKit's
    own Contrib module — resolved through RDConfig so it works on any machine
    with RDKit installed, not just the author's local Anaconda path)
  - PAINS alerts (pan-assay interference structures)
  - Rigidity / flexibility descriptors: rotatable bonds, rotatable-bond
    fraction, Fraction Csp3, ring counts, Bertz complexity

Usage:
    python molecular_triage.py --input data/example_molecules.csv --output outputs/triage_results.csv --plot
"""

import argparse
import os
import sys

import pandas as pd
from rdkit import Chem, RDConfig
from rdkit.Chem import Crippen, Descriptors, Lipinski, QED, rdMolDescriptors
from rdkit.Chem import FilterCatalog

# ---------------------------------------------------------------------------
# SA Score: use RDKit's own bundled Contrib script rather than a hardcoded
# path, so this works on any machine/OS where RDKit is installed.
# ---------------------------------------------------------------------------
sys.path.append(os.path.join(RDConfig.RDContribDir, "SA_Score"))
import sascorer  # noqa: E402


def load_molecules(path: str, smiles_col: str = "SMILES") -> pd.DataFrame:
    """Load a CSV or Excel file and parse a SMILES column into RDKit Mols."""
    if path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)

    if smiles_col not in df.columns:
        raise ValueError(f"Expected a '{smiles_col}' column, found: {list(df.columns)}")

    df["mol"] = df[smiles_col].apply(Chem.MolFromSmiles)
    n_before = len(df)
    df = df[df["mol"].notnull()].copy()
    n_dropped = n_before - len(df)
    if n_dropped:
        print(f"Warning: dropped {n_dropped} row(s) with unparseable SMILES.")
    return df


def lipinski_analysis(mol) -> pd.Series:
    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    hbd = Lipinski.NumHDonors(mol)
    hba = Lipinski.NumHAcceptors(mol)

    violations = []
    if mw > 500:
        violations.append("MW > 500")
    if logp > 5:
        violations.append("LogP > 5")
    if hbd > 5:
        violations.append("HBD > 5")
    if hba > 10:
        violations.append("HBA > 10")

    return pd.Series({
        "MolWt": round(mw, 2),
        "LogP": round(logp, 2),
        "HBD": hbd,
        "HBA": hba,
        "Lipinski_Violations": len(violations),
        "Violation_Details": "None" if not violations else ", ".join(violations),
    })


def rigidity_descriptors(mol) -> pd.Series:
    rotatable_bonds = Lipinski.NumRotatableBonds(mol)
    heavy_atoms = Descriptors.HeavyAtomCount(mol)
    return pd.Series({
        "Num_Rotatable_Bonds": rotatable_bonds,
        "Rotatable_Bond_Fraction": rotatable_bonds / heavy_atoms if heavy_atoms else 0,
        "Fraction_Csp3": rdMolDescriptors.CalcFractionCSP3(mol),
        "Ring_Count": rdMolDescriptors.CalcNumRings(mol),
        "Aromatic_Ring_Count": rdMolDescriptors.CalcNumAromaticRings(mol),
        "Heavy_Atom_Count": heavy_atoms,
        "Bertz_Complexity": round(Descriptors.BertzCT(mol), 1),
    })


def build_pains_catalog() -> FilterCatalog.FilterCatalog:
    params = FilterCatalog.FilterCatalogParams()
    params.AddCatalog(FilterCatalog.FilterCatalogParams.FilterCatalogs.PAINS)
    return FilterCatalog.FilterCatalog(params)


def pains_flag(mol, catalog) -> str:
    entry = catalog.GetFirstMatch(mol)
    return entry.GetDescription() if entry else "None"


def run_triage(input_path: str, output_path: str, make_plot: bool) -> pd.DataFrame:
    df = load_molecules(input_path)

    df = pd.concat([df, df["mol"].apply(lipinski_analysis)], axis=1)
    df["QED"] = df["mol"].apply(QED.qed)
    df["SA_Score"] = df["mol"].apply(sascorer.calculateScore)
    df = pd.concat([df, df["mol"].apply(rigidity_descriptors)], axis=1)

    pains_catalog = build_pains_catalog()
    df["PAINS_Alert"] = df["mol"].apply(lambda m: pains_flag(m, pains_catalog))

    result = df.drop(columns=["mol"])

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    if output_path.lower().endswith((".xlsx", ".xls")):
        result.to_excel(output_path, index=False)
    else:
        result.to_csv(output_path, index=False)
    print(f"Saved {len(result)} molecules -> {output_path}")

    if make_plot:
        make_summary_plot(result, output_path)

    return result


def make_summary_plot(result: pd.DataFrame, output_path: str) -> None:
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 5))
    passed = result["Lipinski_Violations"] == 0
    ax.scatter(result.loc[passed, "SA_Score"], result.loc[passed, "QED"],
               label="Passes Ro5", alpha=0.8)
    ax.scatter(result.loc[~passed, "SA_Score"], result.loc[~passed, "QED"],
               label="Ro5 violation(s)", alpha=0.8, marker="x")
    ax.set_xlabel("Synthetic Accessibility Score (1 = easy, 10 = hard)")
    ax.set_ylabel("QED (drug-likeness, 0-1)")
    ax.set_title("Drug-likeness vs. synthetic accessibility")
    ax.legend()
    fig.tight_layout()

    plot_path = os.path.splitext(output_path)[0] + "_plot.png"
    fig.savefig(plot_path, dpi=150)
    print(f"Saved plot -> {plot_path}")


def parse_args():
    parser = argparse.ArgumentParser(description="Quick drug-likeness/rigidity triage for a molecule set.")
    parser.add_argument("--input", default="data/example_molecules.csv",
                         help="CSV or Excel file with a SMILES column (default: bundled example set)")
    parser.add_argument("--output", default="outputs/triage_results.csv",
                         help="Where to write the results table")
    parser.add_argument("--plot", action="store_true",
                         help="Also save a QED-vs-SA_Score scatter plot")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_triage(args.input, args.output, args.plot)
